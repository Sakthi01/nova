<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Products extends Model
{
    protected $connection = 'mysql3';
    protected $table = "products";
    protected $fillable = ['category_id', 'product_name', 'description', 'unit', 'unit_price', 'tax', 'is_active'];
}
