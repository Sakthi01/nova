<?php $__env->startSection('content'); ?>
<!-- <div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header"><?php echo e(__('Dashboard')); ?></div>

                <div class="card-body">
                    <?php if(session('status')): ?>
                        <div class="alert alert-success" role="alert">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>

                    <?php echo e(__('You are logged in!')); ?>

                </div>
            </div>
        </div>
    </div>
</div> -->
<div class="container">
<form class="form" method="post" action="/category-store" enctype="multipart/form-data">
              <?php echo csrf_field(); ?>
             
  <div class="form-group">
    <label for="exampleInputEmail1">Category Name</label>
    <input type="text" class="form-control" required 
    id="category_name" name="category_name" 
    placeholder="Enter categoryname">
    <small id="emailHelp" class="form-text text-muted">Categoryname should be unique</small>
  </div>
  <div class="form-group">
    <label>Description</label>
    <textarea class="form-control" placeholder="Description" 
    name="description" rows="4" required></textarea>
  </div>
  <button type="submit" class="btn btn-primary">Submit</button>
  <?php if(Session::has('message')): ?>
   <div class="alert alert-info"><?php echo e(Session::get('message')); ?></div>
<?php endif; ?>
</form>
    <h3>Category List</h3>
    <table class="table table-bordered data-table" id="category_table">
        <thead>
            <tr>
                <th>No</th>
                <th>Name</th>
                <th width="100px">Action</th>
            </tr>
        </thead>
        <tbody>
        </tbody>
    </table>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/pratices/novastrid/resources/views/categories.blade.php ENDPATH**/ ?>