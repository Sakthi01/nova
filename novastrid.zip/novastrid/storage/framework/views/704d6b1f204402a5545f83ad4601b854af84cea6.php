<?php $__env->startSection('content'); ?>
<!-- <div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header"><?php echo e(__('Dashboard')); ?></div>

                <div class="card-body">
                    <?php if(session('status')): ?>
                        <div class="alert alert-success" role="alert">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>

                    <?php echo e(__('You are logged in!')); ?>

                </div>
            </div>
        </div>
    </div>
</div> -->
<div class="container">

<h3>Products </h3>
<form class="form" method="post" action="/product-store" enctype="multipart/form-data">
    <?php echo csrf_field(); ?>
    <div class="row">
    <div class="col-md-6">
        <div class="form-group">
            <label>Select Category</label>
                <div class="controls">
                    <select name="category_id" id="category_id" class="form-control" 
                        placeholder="Select Category">
                </select>
            <div class="help-block"></div></div>
        </div>
    </div>
    <div class="col-md-6">
        <div class="form-group">
            <label>Product Name</label>
                <input type="text" class="form-control" name="product_name" id="product_name" required maxlength="20" required>
        </div>
    </div>
    <div class="col-md-12">
        <div class="form-group">
            <label>Description</label>
                <textarea class="form-control" name="product_description" id="product_description" required maxlength="20" required></textarea>
        </div>
    </div>
    <div class="col-md-6">
        <div class="form-group">
            <label>Unit</label>
            <select class="form-control" name="unit" id="unit">
                <option value="Kg">Kg</option>
                <option value="Liter">Liter</option>
                <option value="ML">Milliliter</option>
            </select>
        </div>
    </div>
    <div class="col-md-3">
        <div class="form-group">
            <label>Tax</label>
                <input type="number" class="form-control" name="tax" id="tax" required required>
        </div>
    </div>
    <div class="col-md-3">
        <div class="form-group">
            <label>Unit Price</label>
                <input type="number" class="form-control" name="unit_price" id="unit_price" required required>
        </div>
    </div>
    </div>
    <button type="submit" class="btn btn-success">Submit</button>
    <?php if(Session::has('product_message')): ?>
   <div class="alert alert-info"><?php echo e(Session::get('product_message')); ?></div>
<?php endif; ?>
</form>
<h3>Product List</h3>
    <table class="table table-bordered product-table" id="product-table">
        <thead>
            <tr>
                <th>No</th>
                <th>Name</th>
                <th>Unit</th>
                <th>Unit Price</th>
                <th width="100px">Action</th>
            </tr>
        </thead>
        <tbody>
        </tbody>
    </table>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/pratices/novastrid/resources/views/products.blade.php ENDPATH**/ ?>