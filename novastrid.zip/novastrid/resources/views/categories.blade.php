@extends('layouts.app')

@section('content')
<!-- <div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">{{ __('Dashboard') }}</div>

                <div class="card-body">
                    @if (session('status'))
                        <div class="alert alert-success" role="alert">
                            {{ session('status') }}
                        </div>
                    @endif

                    {{ __('You are logged in!') }}
                </div>
            </div>
        </div>
    </div>
</div> -->
<div class="container">
<form class="form" method="post" action="/category-store" enctype="multipart/form-data">
              @csrf
             
  <div class="form-group">
    <label for="exampleInputEmail1">Category Name</label>
    <input type="text" class="form-control" required 
    id="category_name" name="category_name" 
    placeholder="Enter categoryname">
    <small id="emailHelp" class="form-text text-muted">Categoryname should be unique</small>
  </div>
  <div class="form-group">
    <label>Description</label>
    <textarea class="form-control" placeholder="Description" 
    name="description" rows="4" required></textarea>
  </div>
  <button type="submit" class="btn btn-primary">Submit</button>
  @if (Session::has('message'))
   <div class="alert alert-info">{{ Session::get('message') }}</div>
@endif
</form>
    <h3>Category List</h3>
    <table class="table table-bordered data-table" id="category_table">
        <thead>
            <tr>
                <th>No</th>
                <th>Name</th>
                <th width="100px">Action</th>
            </tr>
        </thead>
        <tbody>
        </tbody>
    </table>
</div>

@endsection
